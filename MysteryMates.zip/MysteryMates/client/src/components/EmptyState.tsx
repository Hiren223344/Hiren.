export function EmptyState() {
  return (
    <div className="h-full flex flex-col items-center justify-center p-8">
      <h1 className="text-2xl font-semibold mb-6 text-white">What can I help with?</h1>
    </div>
  );
}
